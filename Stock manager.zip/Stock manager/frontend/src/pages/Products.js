import React, { useState, useEffect } from 'react';
import { 
  Card, 
  Table, 
  Button, 
  Modal, 
  Form, 
  Row, 
  Col, 
  InputGroup,
  Badge,
  Alert
} from 'react-bootstrap';
import { FaPlus, FaSearch, FaEdit, FaTrash, FaEye, FaExclamationTriangle } from 'react-icons/fa';
import Swal from 'sweetalert2';
import { Notify } from 'notiflix';
import { toast } from 'react-toastify';

const Products = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [showLowStock, setShowLowStock] = useState(false);
  const [lowStockWarningsShown, setLowStockWarningsShown] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    price: '',
    stock: '',
    min_stock: '',
    category_id: ''
  });

  useEffect(() => {
    fetchProducts();
    setLowStockWarningsShown(false);
  }, []);

  // تابع بررسی محصولات کم موجود و نمایش هشدار
  const checkLowStockProducts = (productsList) => {
    if (lowStockWarningsShown) return; // جلوگیری از نمایش مکرر هشدارها
    
    const lowStockProducts = productsList.filter(product => 
      product.stock <= product.min_stock && product.stock > 0
    );
    
    const outOfStockProducts = productsList.filter(product => 
      product.stock === 0
    );

    // نمایش هشدار برای محصولات کم موجود
    if (lowStockProducts.length > 0) {
      const productNames = lowStockProducts.map(p => p.name).join('، ');
      toast.warning(
        <div>
          <div><strong>هشدار موجودی کم!</strong></div>
          <div>محصولات زیر موجودی کمی دارند:</div>
          <div>{productNames}</div>
        </div>,
        {
          position: "top-right",
          autoClose: 8000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          icon: <FaExclamationTriangle />,
        }
      );
    }

    // نمایش هشدار برای محصولات ناموجود
    if (outOfStockProducts.length > 0) {
      const productNames = outOfStockProducts.map(p => p.name).join('، ');
      toast.error(
        <div>
          <div><strong>هشدار موجودی صفر!</strong></div>
          <div>محصولات زیر موجودی ندارند:</div>
          <div>{productNames}</div>
        </div>,
        {
          position: "top-right",
          autoClose: 10000,
          hideProgressBar: false,
          closeOnClick: true,
          pauseOnHover: true,
          draggable: true,
          icon: <FaExclamationTriangle />,
        }
      );
    }

    setLowStockWarningsShown(true);
  };

  const fetchProducts = async () => {
    try {
      let url = '/api/products';
      const params = new URLSearchParams();
      
      if (searchTerm) params.append('search', searchTerm);
      if (showLowStock) params.append('minStock', 'true');
      
      if (params.toString()) {
        url += '?' + params.toString();
      }

      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        setProducts(data);
        
        // بررسی محصولات کم موجود و نمایش هشدار
        checkLowStockProducts(data);
      } else {
        Notify.failure('خطا در دریافت محصولات');
      }
    } catch (error) {
      Notify.failure('خطا در اتصال به سرور');
    } finally {
      setLoading(false);
    }
  };

  // تابع بررسی دستی موجودی کم
  const checkLowStockManually = () => {
    setLowStockWarningsShown(false);
    checkLowStockProducts(products);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const url = editingProduct 
        ? `/api/products/${editingProduct.id}`
        : '/api/products';
      
      const method = editingProduct ? 'PUT' : 'POST';
      
      const response = await fetch(url, {
        method,
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const result = await response.json();
        Notify.success(editingProduct ? 'محصول با موفقیت ویرایش شد' : 'محصول با موفقیت افزوده شد');
        
        // بررسی موجودی کم بعد از ذخیره
        const newStock = parseInt(formData.stock);
        const minStock = parseInt(formData.min_stock);
        
        if (newStock <= minStock) {
          toast.warning(
            <div>
              <div><strong>هشدار موجودی کم!</strong></div>
              <div>محصول "{formData.name}" موجودی کمی دارد</div>
              <div>موجودی فعلی: {newStock} | حداقل موجودی: {minStock}</div>
            </div>,
            {
              position: "top-right",
              autoClose: 8000,
              hideProgressBar: false,
              closeOnClick: true,
              pauseOnHover: true,
              draggable: true,
              icon: <FaExclamationTriangle />,
            }
          );
        }
        
        setShowModal(false);
        resetForm();
        fetchProducts();
      } else {
        const error = await response.json();
        Notify.failure(error.message || 'خطا در ذخیره محصول');
      }
    } catch (error) {
      Notify.failure('خطا در اتصال به سرور');
    }
  };

  const handleDelete = async (id) => {
    const result = await Swal.fire({
      title: 'آیا مطمئن هستید؟',
      text: 'این عملیات قابل بازگشت نیست!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'بله، حذف کن!',
      cancelButtonText: 'لغو'
    });

    if (result.isConfirmed) {
      try {
        const response = await fetch(`/api/products/${id}`, {
          method: 'DELETE',
        });

        if (response.ok) {
          Notify.success('محصول با موفقیت حذف شد');
          fetchProducts();
        } else {
          Notify.failure('خطا در حذف محصول');
        }
      } catch (error) {
        Notify.failure('خطا در اتصال به سرور');
      }
    }
  };

  const handleEdit = (product) => {
    setEditingProduct(product);
    setFormData({
      name: product.name,
      description: product.description || '',
      price: product.price,
      stock: product.stock,
      min_stock: product.min_stock,
    });
    setShowModal(true);
  };

  const resetForm = () => {
    setFormData({
      name: '',
      description: '',
      price: '',
      stock: '',
      min_stock: '',
      category_id: ''
    });
    setEditingProduct(null);
  };

  const formatNumber = (num) => {
    return new Intl.NumberFormat('fa-IR').format(num);
  };

  const formatCurrency = (num) => {
    return new Intl.NumberFormat('fa-IR').format(num) + ' تومان';
  };

  const getStockStatusClass = (stock, minStock) => {
    if (stock === 0) return 'stock-zero';
    if (stock <= minStock) return 'stock-low';
    return 'stock-ok';
  };

  const getStockStatusText = (stock, minStock) => {
    if (stock === 0) return 'ناموجود';
    if (stock <= minStock) return 'کم‌موجود';
    return 'موجود';
  };

  // تابع تبدیل اعداد به حروف فارسی
  const numberToPersianWords = (num) => {
    if (!num || num === '0' || num === 0) return 'صفر';
    
    const ones = ['', 'یک', 'دو', 'سه', 'چهار', 'پنج', 'شش', 'هفت', 'هشت', 'نه'];
    const tens = ['', 'ده', 'بیست', 'سی', 'چهل', 'پنجاه', 'شصت', 'هفتاد', 'هشتاد', 'نود'];
    const hundreds = ['', 'صد', 'دویست', 'سیصد', 'چهارصد', 'پانصد', 'ششصد', 'هفتصد', 'هشتصد', 'نهصد'];
    const thousands = ['', 'هزار', 'میلیون', 'میلیارد', 'هزار میلیارد', 'میلیارد میلیارد'];
    
    const convertLessThanOneThousand = (n) => {
      if (n === 0) return '';
      
      if (n < 10) return ones[n];
      
      if (n < 20) {
        const teens = ['ده', 'یازده', 'دوازده', 'سیزده', 'چهارده', 'پانزده', 'شانزده', 'هفده', 'هجده', 'نوزده'];
        return teens[n - 10];
      }
      
      if (n < 100) {
        return tens[Math.floor(n / 10)] + (n % 10 !== 0 ? ' و ' + ones[n % 10] : '');
      }
      
      if (n < 1000) {
        return hundreds[Math.floor(n / 100)] + (n % 100 !== 0 ? ' و ' + convertLessThanOneThousand(n % 100) : '');
      }
    };
    
    const convert = (n) => {
      if (n === 0) return 'صفر';
      
      let result = '';
      let groupIndex = 0;
      
      while (n > 0) {
        const group = n % 1000;
        if (group !== 0) {
          const groupWords = convertLessThanOneThousand(group);
          if (groupIndex > 0) {
            result = groupWords + ' ' + thousands[groupIndex] + (result ? ' و ' + result : '');
          } else {
            result = groupWords;
          }
        }
        n = Math.floor(n / 1000);
        groupIndex++;
      }
      
      return result;
    };
    
    return convert(parseInt(num)) + ' تومان';
  };

  if (loading) {
    return (
      <div className="text-center p-5">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">در حال بارگذاری...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="fade-in">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>مدیریت محصولات</h2>
        <div>
          <Button 
            variant="warning" 
            onClick={checkLowStockManually}
            className="me-2 btn-check-stock"
          >
            <FaExclamationTriangle className="me-2" />
            بررسی موجودی کم
          </Button>
          <Button 
            variant="primary" 
            onClick={() => setShowModal(true)}
          >
            <FaPlus className="me-2" />
            افزودن محصول جدید
          </Button>
        </div>
      </div>

      {/* خلاصه وضعیت موجودی */}
      <Card className="mb-4 low-stock-warning">
        <Card.Body>
          <Row>
            <Col md={3}>
              <div className="text-center">
                <div className="h4 text-warning mb-0">
                  {products.filter(p => p.stock <= p.min_stock && p.stock > 0).length}
                </div>
                <small className="text-muted">کم موجود</small>
              </div>
            </Col>
            <Col md={3}>
              <div className="text-center">
                <div className="h4 text-danger mb-0">
                  {products.filter(p => p.stock === 0).length}
                </div>
                <small className="text-muted">ناموجود</small>
              </div>
            </Col>
            <Col md={3}>
              <div className="text-center">
                <div className="h4 text-success mb-0">
                  {products.filter(p => p.stock > p.min_stock).length}
                </div>
                <small className="text-muted">موجود</small>
              </div>
            </Col>
            <Col md={3}>
              <div className="text-center">
                <div className="h4 text-primary mb-0">
                  {products.length}
                </div>
                <small className="text-muted">کل محصولات</small>
              </div>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      {/* فیلترها */}
      <Card className="mb-4">
        <Card.Body>
          <Row>
            <Col md={4}>
              <InputGroup>
                <InputGroup.Text>
                  <FaSearch />
                </InputGroup.Text>
                <Form.Control
                  placeholder="جستجو در محصولات..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </InputGroup>
            </Col>
            <Col md={3}>
              <Form.Check
                type="checkbox"
                label="فقط کم‌موجود"
                checked={showLowStock}
                onChange={(e) => setShowLowStock(e.target.checked)}
              />
            </Col>
            <Col md={2}>
              <Button 
                variant="outline-primary" 
                onClick={() => {
                  setLowStockWarningsShown(false);
                  fetchProducts();
                }}
                className="w-100"
              >
                اعمال فیلتر
              </Button>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      {/* جدول محصولات */}
      <Card>
        <Card.Header>
          لیست محصولات ({products.length} مورد)
        </Card.Header>
        <Card.Body>
          {products.length === 0 ? (
            <Alert variant="info">
              محصولی یافت نشد.
            </Alert>
          ) : (
            <Table responsive hover>
              <thead>
                <tr>
                  <th>نام محصول</th>
                  <th>قیمت</th>
                  <th>موجودی</th>
                  <th>وضعیت</th>
                  <th>عملیات</th>
                </tr>
              </thead>
              <tbody>
                {products.map(product => (
                  <tr 
                    key={product.id}
                    className={
                      product.stock === 0 ? 'out-of-stock-row' : 
                      product.stock <= product.min_stock ? 'low-stock-row' : ''
                    }
                  >
                    <td>
                      <div>
                        <strong>{product.name}</strong>
                        {product.description && (
                          <small className="text-muted d-block">
                            {product.description}
                          </small>
                        )}
                      </div>
                    </td>
                    <td>{formatCurrency(product.price)}</td>
                    <td>
                      <span className={getStockStatusClass(product.stock, product.min_stock)}>
                        {formatNumber(product.stock)}
                      </span>
                    </td>
                    <td>
                      <Badge 
                        bg={product.stock === 0 ? 'danger' : 
                            product.stock <= product.min_stock ? 'warning' : 'success'}
                      >
                        {getStockStatusText(product.stock, product.min_stock)}
                      </Badge>
                    </td>
                    <td>
                      <Button
                        variant="outline-primary"
                        size="sm"
                        className="me-1"
                        onClick={() => handleEdit(product)}
                      >
                        <FaEdit />
                      </Button>
                      <Button
                        variant="outline-danger"
                        size="sm"
                        onClick={() => handleDelete(product.id)}
                      >
                        <FaTrash />
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card.Body>
      </Card>

      {/* مودال افزودن/ویرایش */}
      <Modal show={showModal} onHide={() => setShowModal(false)} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>
            {editingProduct ? 'ویرایش محصول' : 'افزودن محصول جدید'}
          </Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSubmit}>
          <Modal.Body>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>نام محصول *</Form.Label>
                  <Form.Control
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                    required
                  />
                </Form.Group>
              </Col>
            </Row>
            <Form.Group className="mb-3">
              <Form.Label>توضیحات</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                value={formData.description}
                onChange={(e) => setFormData({...formData, description: e.target.value})}
              />
            </Form.Group>
            <Row>
              <Col md={4}>
                <Form.Group className="mb-3">
                  <Form.Label>قیمت (تومان) *</Form.Label>
                  <Form.Control
                    type="number"
                    value={formData.price}
                    onChange={(e) => setFormData({...formData, price: e.target.value})}
                    required
                    min="0"
                  />
                  {formData.price && formData.price !== '0' && (
                    <div className="mt-2 text-info small">
                       {numberToPersianWords(formData.price)}
                    </div>
                  )}
                </Form.Group>
              </Col>
              <Col md={4}>
                <Form.Group className="mb-3">
                  <Form.Label>موجودی *</Form.Label>
                  <Form.Control
                    type="number"
                    value={formData.stock}
                    onChange={(e) => setFormData({...formData, stock: e.target.value})}
                    required
                    min="0"
                  />
                </Form.Group>
              </Col>
              <Col md={4}>
                <Form.Group className="mb-3">
                  <Form.Label>حداقل موجودی *</Form.Label>
                  <Form.Control
                    type="number"
                    value={formData.min_stock}
                    onChange={(e) => setFormData({...formData, min_stock: e.target.value})}
                    required
                    min="0"
                  />
                </Form.Group>
              </Col>
            </Row>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowModal(false)}>
              لغو
            </Button>
            <Button variant="primary" type="submit">
              {editingProduct ? 'ویرایش' : 'افزودن'}
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
    </div>
  );
};

export default Products; 