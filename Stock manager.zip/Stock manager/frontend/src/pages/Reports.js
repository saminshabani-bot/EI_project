import React, { useState, useEffect } from 'react';
import { 
  Card, 
  Table, 
  Button, 
  Form, 
  Row, 
  Col, 
  Nav,
  Tab
} from 'react-bootstrap';
import { 
  FaChartBar, 
  FaChartLine, 
  FaChartPie,
} from 'react-icons/fa';
import { Line, Bar, Pie } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { Notify } from 'notiflix';

ChartJS.register(
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend
);

const Reports = () => {
  const [activeTab, setActiveTab] = useState('sales');
  const [salesData, setSalesData] = useState([]);
  const [inventoryData, setInventoryData] = useState([]);
  const [orderStatusData, setOrderStatusData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    startDate: '',
    endDate: '',
    groupBy: 'day'
  });

  useEffect(() => {
    fetchData();
  }, [activeTab, filters]);

  const fetchData = async () => {
    setLoading(true);
    try {
      switch (activeTab) {
        case 'sales':
          await fetchSalesReport();
          break;
        case 'inventory':
          await fetchInventoryReport();
          break;
        case 'orders':
          await fetchOrderStatusReport();
          break;
      }
    } catch (error) {
      Notify.failure('خطا در دریافت گزارشات');
    } finally {
      setLoading(false);
    }
  };

  const fetchSalesReport = async () => {
    try {
      const params = new URLSearchParams();
      if (filters.startDate) params.append('startDate', filters.startDate);
      if (filters.endDate) params.append('endDate', filters.endDate);
      if (filters.groupBy) params.append('groupBy', filters.groupBy);

      const response = await fetch(`/api/reports/sales?${params}`);
      if (response.ok) {
        const data = await response.json();
        setSalesData(data);
      }
    } catch (error) {
      console.error('خطا در دریافت گزارش فروش:', error);
    }
  };

  const fetchInventoryReport = async () => {
    try {
      const response = await fetch('/api/reports/inventory');
      if (response.ok) {
        const data = await response.json();
        setInventoryData(data);
      }
    } catch (error) {
      console.error('خطا در دریافت گزارش موجودی:', error);
    }
  };

  const fetchOrderStatusReport = async () => {
    try {
      const params = new URLSearchParams();
      if (filters.startDate) params.append('startDate', filters.startDate);
      if (filters.endDate) params.append('endDate', filters.endDate);

      const response = await fetch(`/api/reports/order-status?${params}`);
      if (response.ok) {
        const data = await response.json();
        setOrderStatusData(data);
      }
    } catch (error) {
      console.error('خطا در دریافت گزارش وضعیت سفارشات:', error);
    }
  };

  const formatNumber = (num) => {
    return new Intl.NumberFormat('fa-IR').format(num);
  };

  const formatCurrency = (num) => {
    return new Intl.NumberFormat('fa-IR').format(num) + ' تومان';
  };

  const getSalesChartData = () => {
    if (filters.groupBy === 'day') {
      return {
        labels: salesData.map(item => item.date),
        datasets: [
          {
            label: 'فروش روزانه',
            data: salesData.map(item => item.total_revenue),
            borderColor: 'rgb(102, 126, 234)',
            backgroundColor: 'rgba(102, 126, 234, 0.1)',
            tension: 0.4,
          },
        ],
      };
    } else {
      return {
        labels: salesData.map(item => item.product_name),
        datasets: [
          {
            label: 'فروش',
            data: salesData.map(item => item.total_revenue),
            backgroundColor: [
              'rgba(102, 126, 234, 0.8)',
              'rgba(86, 171, 47, 0.8)',
              'rgba(255, 65, 108, 0.8)',
              'rgba(240, 147, 251, 0.8)',
              'rgba(255, 75, 43, 0.8)',
            ],
          },
        ],
      };
    }
  };

  const getOrderStatusChartData = () => {
    return {
      labels: orderStatusData.map(item => {
        const statusMap = {
          pending: 'در انتظار',
          shipped: 'ارسال شده',
          cancelled: 'لغو شده'
        };
        return statusMap[item.status] || item.status;
      }),
      datasets: [
        {
          data: orderStatusData.map(item => item.count),
          backgroundColor: [
            'rgba(255, 193, 7, 0.8)',
            'rgba(40, 167, 69, 0.8)',
            'rgba(220, 53, 69, 0.8)',
          ],
        },
      ],
    };
  };

  if (loading) {
    return (
      <div className="text-center p-5">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">در حال بارگذاری...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="fade-in">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>گزارشات و تحلیل</h2>
      </div>

      {/* فیلترها */}
      <Card className="mb-4">
        <Card.Body>
          <Row>
            <Col md={3}>
              <Form.Group>
                <Form.Label>از تاریخ</Form.Label>
                <Form.Control
                  type="date"
                  value={filters.startDate}
                  onChange={(e) => setFilters({...filters, startDate: e.target.value})}
                />
              </Form.Group>
            </Col>
            <Col md={3}>
              <Form.Group>
                <Form.Label>تا تاریخ</Form.Label>
                <Form.Control
                  type="date"
                  value={filters.endDate}
                  onChange={(e) => setFilters({...filters, endDate: e.target.value})}
                />
              </Form.Group>
            </Col>
            <Col md={3}>
              <Form.Group>
                <Form.Label>گروه‌بندی</Form.Label>
                <Form.Select
                  value={filters.groupBy}
                  onChange={(e) => setFilters({...filters, groupBy: e.target.value})}
                >
                  <option value="day">روزانه</option>
                  <option value="product">بر اساس محصول</option>
                </Form.Select>
              </Form.Group>
            </Col>
            <Col md={3}>
              <Form.Group>
                <Form.Label>&nbsp;</Form.Label>
                <Button 
                  variant="primary" 
                  onClick={fetchData}
                  className="w-100"
                >
                  <FaChartBar className="me-2" />
                  اعمال فیلتر
                </Button>
              </Form.Group>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      {/* تب‌ها */}
      <Card>
        <Card.Header>
          <Nav variant="tabs" activeKey={activeTab} onSelect={setActiveTab}>
            <Nav.Item>
              <Nav.Link eventKey="sales">
                <FaChartLine className="me-1" />
                گزارش فروش
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="inventory">
                <FaChartBar className="me-1" />
                گزارش موجودی
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="orders">
                <FaChartPie className="me-1" />
                وضعیت سفارشات
              </Nav.Link>
            </Nav.Item>
            <Nav.Item>
            </Nav.Item>
          </Nav>
        </Card.Header>
        <Card.Body>
          <Tab.Content>
            <Tab.Pane active={activeTab === 'sales'}>
              <Row>
                <Col md={4}>
                  <Card>
                    <Card.Header>جزئیات فروش</Card.Header>
                    <Card.Body>
                      <Table responsive>
                        <thead>
                          <tr>
                            <th>عنوان</th>
                            <th>فروش</th>
                            <th>درآمد</th>
                          </tr>
                        </thead>
                        <tbody>
                          {salesData.map((item, index) => (
                            <tr key={index}>
                              <td>{item.date || item.product_name}</td>
                              <td>{formatNumber(item.total_quantity)}</td>
                              <td>{formatCurrency(item.total_revenue)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </Table>
                    </Card.Body>
                  </Card>
                </Col>
              </Row>
            </Tab.Pane>

            <Tab.Pane active={activeTab === 'inventory'}>
              <Table responsive hover>
                <thead>
                  <tr>
                    <th>محصول</th>
                    <th>موجودی</th>
                    <th>ارزش موجودی</th>
                    <th>وضعیت</th>
                  </tr>
                </thead>
                <tbody>
                  {inventoryData.map(product => (
                    <tr key={product.id}>
                      <td>
                        <strong>{product.name}</strong>
                        <small className="text-muted d-block">
                          {formatCurrency(product.price)} هر واحد
                        </small>
                      </td>
                      <td>{formatNumber(product.stock)}</td>
                      <td>{formatCurrency(product.stock_value)}</td>
                      <td>
                        <span className={`badge bg-${
                          product.stock_status === 'ناموجود' ? 'danger' :
                          product.stock_status === 'کم‌موجود' ? 'warning' : 'success'
                        }`}>
                          {product.stock_status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Tab.Pane>

            <Tab.Pane active={activeTab === 'orders'}>
              <Row>
                <Col md={6}>
                  <Card>
                    <Card.Header>جزئیات وضعیت سفارشات</Card.Header>
                    <Card.Body>
                      <Table responsive>
                        <thead>
                          <tr>
                            <th>وضعیت</th>
                            <th>تعداد</th>
                            <th>ارزش کل</th>
                          </tr>
                        </thead>
                        <tbody>
                          {orderStatusData.map((item, index) => (
                            <tr key={index}>
                              <td>
                                <span className={`badge bg-${
                                  item.status === 'pending' ? 'warning' :
                                  item.status === 'shipped' ? 'success' : 'danger'
                                }`}>
                                  {item.status === 'pending' ? 'در انتظار' :
                                   item.status === 'shipped' ? 'ارسال شده' : 'لغو شده'}
                                </span>
                              </td>
                              <td>{formatNumber(item.count)}</td>
                              <td>{formatCurrency(item.total_value || 0)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </Table>
                    </Card.Body>
                  </Card>
                </Col>
              </Row>
            </Tab.Pane>
          </Tab.Content>
        </Card.Body>
      </Card>
    </div>
  );
};

export default Reports; 