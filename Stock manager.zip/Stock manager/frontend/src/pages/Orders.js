import React, { useState, useEffect } from 'react';
import { 
  Card, 
  Table, 
  Button, 
  Modal, 
  Form, 
  Row, 
  Col, 
  InputGroup,
  Badge,
  Alert
} from 'react-bootstrap';
import { FaPlus, FaSearch, FaEdit, FaTrash, FaEye } from 'react-icons/fa';
import Swal from 'sweetalert2';
import { Notify } from 'notiflix';
import moment from 'moment-jalaali';

const Orders = () => {
  const [orders, setOrders] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const [formData, setFormData] = useState({
    product_id: '',
    quantity: '',
    customer_name: '',
    customer_phone: '',
    notes: ''
  });

  useEffect(() => {
    fetchOrders();
    fetchProducts();
  }, []);

  const fetchOrders = async () => {
    try {
      let url = '/api/orders';
      const params = new URLSearchParams();
      
      if (searchTerm) params.append('search', searchTerm);
      if (selectedStatus) params.append('status', selectedStatus);
      if (startDate) params.append('startDate', startDate);
      if (endDate) params.append('endDate', endDate);
      
      if (params.toString()) {
        url += '?' + params.toString();
      }

      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        setOrders(data);
      } else {
        Notify.failure('خطا در دریافت سفارشات');
      }
    } catch (error) {
      Notify.failure('خطا در اتصال به سرور');
    } finally {
      setLoading(false);
    }
  };

  const fetchProducts = async () => {
    try {
      const response = await fetch('/api/products');
      if (response.ok) {
        const data = await response.json();
        setProducts(data);
      }
    } catch (error) {
      console.error('خطا در دریافت محصولات:', error);
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const response = await fetch('/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(formData),
      });

      if (response.ok) {
        const result = await response.json();
        Notify.success('سفارش با موفقیت ثبت شد');
        setShowModal(false);
        resetForm();
        fetchOrders();
      } else {
        const error = await response.json();
        Notify.failure(error.message || 'خطا در ثبت سفارش');
      }
    } catch (error) {
      Notify.failure('خطا در اتصال به سرور');
    }
  };

  const handleStatusChange = async (orderId, newStatus) => {
    try {
      const response = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: newStatus }),
      });

      if (response.ok) {
        Notify.success('وضعیت سفارش با موفقیت تغییر کرد');
        fetchOrders();
      } else {
        Notify.failure('خطا در تغییر وضعیت سفارش');
      }
    } catch (error) {
      Notify.failure('خطا در اتصال به سرور');
    }
  };

  const handleDelete = async (id) => {
    const result = await Swal.fire({
      title: 'آیا مطمئن هستید؟',
      text: 'این عملیات قابل بازگشت نیست!',
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'بله، حذف کن!',
      cancelButtonText: 'لغو'
    });

    if (result.isConfirmed) {
      try {
        const response = await fetch(`/api/orders/${id}`, {
          method: 'DELETE',
        });

        if (response.ok) {
          Notify.success('سفارش با موفقیت حذف شد');
          fetchOrders();
        } else {
          Notify.failure('خطا در حذف سفارش');
        }
      } catch (error) {
        Notify.failure('خطا در اتصال به سرور');
      }
    }
  };

  const resetForm = () => {
    setFormData({
      product_id: '',
      quantity: '',
      customer_name: '',
      customer_phone: '',
      notes: ''
    });
  };

  const formatNumber = (num) => {
    return new Intl.NumberFormat('fa-IR').format(num);
  };

  const formatCurrency = (num) => {
    return new Intl.NumberFormat('fa-IR').format(num) + ' تومان';
  };

  const getStatusBadge = (status) => {
    const statusConfig = {
      pending: { bg: 'warning', text: 'در انتظار' },
      shipped: { bg: 'success', text: 'ارسال شده' },
      cancelled: { bg: 'danger', text: 'لغو شده' }
    };
    
    const config = statusConfig[status] || { bg: 'secondary', text: status };
    return <Badge bg={config.bg}>{config.text}</Badge>;
  };

  const getStatusOptions = () => {
    return [
      { value: 'pending', label: 'در انتظار' },
      { value: 'shipped', label: 'ارسال شده' },
      { value: 'cancelled', label: 'لغو شده' }
    ];
  };

  if (loading) {
    return (
      <div className="text-center p-5">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">در حال بارگذاری...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="fade-in">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>مدیریت سفارشات</h2>
        <Button 
          variant="primary" 
          onClick={() => setShowModal(true)}
        >
          <FaPlus className="me-2" />
          ثبت سفارش جدید
        </Button>
      </div>

      {/* فیلترها */}
      <Card className="mb-4">
        <Card.Body>
          <Row>
            <Col md={3}>
              <InputGroup>
                <InputGroup.Text>
                  <FaSearch />
                </InputGroup.Text>
                <Form.Control
                  placeholder="جستجو در سفارشات..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </InputGroup>
            </Col>
            <Col md={2}>
              <Form.Select
                value={selectedStatus}
                onChange={(e) => setSelectedStatus(e.target.value)}
              >
                <option value="">همه وضعیت‌ها</option>
                {getStatusOptions().map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </Form.Select>
            </Col>
            <Col md={2}>
              <Form.Control
                type="date"
                placeholder="از تاریخ"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
              />
            </Col>
            <Col md={2}>
              <Form.Control
                type="date"
                placeholder="تا تاریخ"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
              />
            </Col>
            <Col md={3}>
              <Button 
                variant="outline-primary" 
                onClick={fetchOrders}
                className="w-100"
              >
                اعمال فیلتر
              </Button>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      {/* جدول سفارشات */}
      <Card>
        <Card.Header>
          لیست سفارشات ({orders.length} مورد)
        </Card.Header>
        <Card.Body>
          {orders.length === 0 ? (
            <Alert variant="info">
              سفارشی یافت نشد.
            </Alert>
          ) : (
            <Table responsive hover>
              <thead>
                <tr>
                  <th>شماره سفارش</th>
                  <th>محصول</th>
                  <th>مشتری</th>
                  <th>تعداد</th>
                  <th>مبلغ کل</th>
                  <th>وضعیت</th>
                  <th>تاریخ</th>
                  <th>عملیات</th>
                </tr>
              </thead>
              <tbody>
                {orders.map(order => (
                  <tr key={order.id}>
                    <td>#{order.id}</td>
                    <td>
                      <div>
                        <strong>{order.product_name}</strong>
                        <small className="text-muted d-block">
                          {formatCurrency(order.product_price)} هر واحد
                        </small>
                      </div>
                    </td>
                    <td>
                      <div>
                        <strong>{order.customer_name}</strong>
                        <small className="text-muted d-block">
                          {order.customer_phone}
                        </small>
                      </div>
                    </td>
                    <td>{formatNumber(order.quantity)}</td>
                    <td>{formatCurrency(order.total_price)}</td>
                    <td>{getStatusBadge(order.status)}</td>
                    <td>{moment(order.created_at).format('jYYYY/jMM/jDD HH:mm')}</td>
                    <td>
                      <div className="d-flex gap-1">
                        <Form.Select
                          size="sm"
                          value={order.status}
                          onChange={(e) => handleStatusChange(order.id, e.target.value)}
                          style={{ width: 'auto' }}
                        >
                          {getStatusOptions().map(option => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))}
                        </Form.Select>
                        <Button
                          variant="outline-danger"
                          size="sm"
                          onClick={() => handleDelete(order.id)}
                        >
                          <FaTrash />
                        </Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          )}
        </Card.Body>
      </Card>

      {/* مودال ثبت سفارش */}
      <Modal show={showModal} onHide={() => setShowModal(false)} size="lg">
        <Modal.Header closeButton>
          <Modal.Title>ثبت سفارش جدید</Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleSubmit}>
          <Modal.Body>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>محصول *</Form.Label>
                  <Form.Select
                    value={formData.product_id}
                    onChange={(e) => setFormData({...formData, product_id: e.target.value})}
                    required
                  >
                    <option value="">انتخاب محصول</option>
                    {products.map(product => (
                      <option key={product.id} value={product.id}>
                        {product.name} - موجودی: {product.stock}
                      </option>
                    ))}
                  </Form.Select>
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>تعداد *</Form.Label>
                  <Form.Control
                    type="number"
                    value={formData.quantity}
                    onChange={(e) => setFormData({...formData, quantity: e.target.value})}
                    required
                    min="1"
                  />
                </Form.Group>
              </Col>
            </Row>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>نام مشتری *</Form.Label>
                  <Form.Control
                    type="text"
                    value={formData.customer_name}
                    onChange={(e) => setFormData({...formData, customer_name: e.target.value})}
                    required
                  />
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>شماره تماس *</Form.Label>
                  <Form.Control
                    type="tel"
                    value={formData.customer_phone}
                    onChange={(e) => setFormData({...formData, customer_phone: e.target.value})}
                    required
                  />
                </Form.Group>
              </Col>
            </Row>
            <Form.Group className="mb-3">
              <Form.Label>توضیحات</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                value={formData.notes}
                onChange={(e) => setFormData({...formData, notes: e.target.value})}
              />
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowModal(false)}>
              لغو
            </Button>
            <Button variant="primary" type="submit">
              ثبت سفارش
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
    </div>
  );
};

export default Orders; 