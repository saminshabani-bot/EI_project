const express = require('express');
const router = express.Router();
const db = require('../config/database');

// Get inventory history with filters
router.get('/history', async (req, res) => {
  try {
    const { product_id, type, startDate, endDate, limit = 100 } = req.query;
    let query = `
      SELECT il.*, p.name as product_name, p.price as product_price
      FROM inventory_logs il
      LEFT JOIN products p ON il.product_id = p.id
      WHERE 1=1
    `;
    const params = [];

    if (product_id) {
      query += ` AND il.product_id = ?`;
      params.push(product_id);
    }

    if (type) {
      query += ` AND il.type = ?`;
      params.push(type);
    }

    if (startDate) {
      query += ` AND DATE(il.created_at) >= ?`;
      params.push(startDate);
    }

    if (endDate) {
      query += ` AND DATE(il.created_at) <= ?`;
      params.push(endDate);
    }

    query += ` ORDER BY il.created_at DESC LIMIT ?`;
    params.push(parseInt(limit));

    db.query(query, params, (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت تاریخچه موجودی' });
      }
      res.json(results);
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Get low stock products
router.get('/low-stock', async (req, res) => {
  try {
    const query = `
      SELECT p.*
      FROM products p
      WHERE p.stock <= p.min_stock
      ORDER BY (p.min_stock - p.stock) DESC
    `;

    db.query(query, (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت کالاهای کم‌موجود' });
      }
      res.json(results);
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Get stock summary
router.get('/summary', async (req, res) => {
  try {
    const summaryQuery = `
      SELECT 
        COUNT(*) as total_products,
        SUM(stock) as total_stock,
        SUM(stock * price) as total_value,
        COUNT(CASE WHEN stock <= min_stock THEN 1 END) as low_stock_count,
        COUNT(CASE WHEN stock = 0 THEN 1 END) as out_of_stock_count
      FROM products
    `;

    db.query(summaryQuery, (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت خلاصه موجودی' });
      }
      res.json(results[0]);
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Get inventory movement by date range
router.get('/movement', async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    let query = `
      SELECT 
        DATE(created_at) as date,
        type,
        SUM(quantity) as total_quantity,
        COUNT(*) as transaction_count
      FROM inventory_logs
      WHERE 1=1
    `;
    const params = [];

    if (startDate) {
      query += ` AND DATE(created_at) >= ?`;
      params.push(startDate);
    }

    if (endDate) {
      query += ` AND DATE(created_at) <= ?`;
      params.push(endDate);
    }

    query += ` GROUP BY DATE(created_at), type ORDER BY date DESC`;

    db.query(query, params, (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت حرکت موجودی' });
      }
      res.json(results);
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Get product stock history
router.get('/product/:id/history', async (req, res) => {
  try {
    const { id } = req.params;
    const { limit = 50 } = req.query;

    const query = `
      SELECT il.*, p.name as product_name
      FROM inventory_logs il
      LEFT JOIN products p ON il.product_id = p.id
      WHERE il.product_id = ?
      ORDER BY il.created_at DESC
      LIMIT ?
    `;

    db.query(query, [id, parseInt(limit)], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت تاریخچه کالا' });
      }
      res.json(results);
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Manual stock adjustment
router.post('/adjust', async (req, res) => {
  try {
    const { product_id, quantity, type, description } = req.body;

    if (!product_id || !quantity || !type) {
      return res.status(400).json({ message: 'تمام فیلدها الزامی هستند' });
    }

    if (!['IN', 'OUT'].includes(type)) {
      return res.status(400).json({ message: 'نوع تراکنش نامعتبر است' });
    }

    // Get current stock
    db.query('SELECT stock, name FROM products WHERE id = ?', [product_id], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت موجودی کالا' });
      }
      if (results.length === 0) {
        return res.status(404).json({ message: 'کالا یافت نشد' });
      }

      const product = results[0];
      let newStock;

      if (type === 'IN') {
        newStock = product.stock + quantity;
      } else {
        if (product.stock < quantity) {
          return res.status(400).json({ message: 'موجودی کافی نیست' });
        }
        newStock = product.stock - quantity;
      }

      // Update stock
      db.query('UPDATE products SET stock = ?, updated_at = NOW() WHERE id = ?', 
        [newStock, product_id], (err, result) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ message: 'خطا در بروزرسانی موجودی' });
        }

        // Log inventory transaction
        const logQuery = `
          INSERT INTO inventory_logs (product_id, type, quantity, description, created_at) 
          VALUES (?, ?, ?, ?, NOW())
        `;
        db.query(logQuery, [product_id, type, quantity, description || 'تنظیم دستی موجودی']);

        res.json({ 
          message: 'موجودی با موفقیت تنظیم شد',
          newStock,
          product_name: product.name
        });
      });
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

module.exports = router; 