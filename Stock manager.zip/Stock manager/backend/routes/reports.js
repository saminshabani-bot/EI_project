const express = require('express');
const router = express.Router();
const db = require('../config/database');

// Get sales report
router.get('/sales', async (req, res) => {
  try {
    const { startDate, endDate, groupBy = 'day' } = req.query;
    let query = '';
    const params = [];

    if (groupBy === 'day') {
      query = `
        SELECT 
          DATE(o.created_at) as date,
          COUNT(*) as order_count,
          SUM(o.quantity) as total_quantity,
          SUM(o.total_price) as total_revenue,
          AVG(o.total_price) as avg_order_value
        FROM orders o
        WHERE o.status != 'cancelled'
      `;
    } else if (groupBy === 'product') {
      query = `
        SELECT 
          p.name as product_name,
          p.id as product_id,
          COUNT(o.id) as order_count,
          SUM(o.quantity) as total_quantity,
          SUM(o.total_price) as total_revenue,
          AVG(o.total_price) as avg_order_value
        FROM orders o
        LEFT JOIN products p ON o.product_id = p.id
        WHERE o.status != 'cancelled'
      `;
    }

    if (startDate) {
      query += ` AND DATE(o.created_at) >= ?`;
      params.push(startDate);
    }

    if (endDate) {
      query += ` AND DATE(o.created_at) <= ?`;
      params.push(endDate);
    }

    if (groupBy === 'day') {
      query += ` GROUP BY DATE(o.created_at) ORDER BY date DESC`;
    } else if (groupBy === 'product') {
      query += ` GROUP BY p.id ORDER BY total_revenue DESC`;
    }

    db.query(query, params, (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت گزارش فروش' });
      }
      res.json(results);
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Get inventory report
router.get('/inventory', async (req, res) => {
  try {
    const { stockStatus } = req.query;
    let query = `
      SELECT 
        p.*,
        c.name as category_name,
        (p.stock * p.price) as stock_value,
        CASE 
          WHEN p.stock = 0 THEN 'ناموجود'
          WHEN p.stock <= p.min_stock THEN 'کم‌موجود'
          ELSE 'موجود'
        END as stock_status
      FROM products p
      LEFT JOIN categories c ON p.category_id = c.id
      WHERE 1=1
    `;
    const params = [];


    if (stockStatus) {
      if (stockStatus === 'out_of_stock') {
        query += ` AND p.stock = 0`;
      } else if (stockStatus === 'low_stock') {
        query += ` AND p.stock <= p.min_stock AND p.stock > 0`;
      } else if (stockStatus === 'in_stock') {
        query += ` AND p.stock > p.min_stock`;
      }
    }

    query += ` ORDER BY p.stock ASC`;

    db.query(query, params, (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت گزارش موجودی' });
      }
      res.json(results);
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Get dashboard summary
router.get('/dashboard', async (req, res) => {
  try {
    const { period = '30' } = req.query;
    
    // Get date range
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - parseInt(period));

    const summaryQuery = `
      SELECT 
        (SELECT COUNT(*) FROM products) as total_products,
        (SELECT SUM(stock) FROM products) as total_stock,
        (SELECT SUM(stock * price) FROM products) as total_inventory_value,
        (SELECT COUNT(*) FROM products WHERE stock <= min_stock) as low_stock_products,
        (SELECT COUNT(*) FROM products WHERE stock = 0) as out_of_stock_products,
        (SELECT COUNT(*) FROM orders WHERE created_at >= ? AND status != 'cancelled') as recent_orders,
        (SELECT SUM(total_price) FROM orders WHERE created_at >= ? AND status != 'cancelled') as recent_revenue,
        (SELECT COUNT(*) FROM orders WHERE status = 'pending') as pending_orders
    `;

    db.query(summaryQuery, [startDate, startDate], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت خلاصه داشبورد' });
      }

      // Get top selling products
      const topProductsQuery = `
        SELECT 
          p.name as product_name,
          p.id as product_id,
          SUM(o.quantity) as total_sold,
          SUM(o.total_price) as total_revenue
        FROM orders o
        LEFT JOIN products p ON o.product_id = p.id
        WHERE o.created_at >= ? AND o.status != 'cancelled'
        GROUP BY p.id
        ORDER BY total_sold DESC
        LIMIT 5
      `;

      db.query(topProductsQuery, [startDate], (err, topProducts) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ message: 'خطا در دریافت محصولات پرفروش' });
        }

        // Get recent inventory movements
        const recentMovementsQuery = `
          SELECT 
            il.*,
            p.name as product_name
          FROM inventory_logs il
          LEFT JOIN products p ON il.product_id = p.id
          WHERE il.created_at >= ?
          ORDER BY il.created_at DESC
          LIMIT 10
        `;

        db.query(recentMovementsQuery, [startDate], (err, recentMovements) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ message: 'خطا در دریافت حرکات اخیر' });
          }

          // Get top customers by purchase amount
          const topCustomersByAmountQuery = `
            SELECT 
              customer_name,
              customer_phone,
              SUM(total_price) as total_purchase_amount,
              COUNT(*) as order_count
            FROM orders
            WHERE created_at >= ? AND status != 'cancelled'
            GROUP BY customer_name, customer_phone
            ORDER BY total_purchase_amount DESC
            LIMIT 5
          `;

          db.query(topCustomersByAmountQuery, [startDate], (err, topCustomersByAmount) => {
            if (err) {
              console.error(err);
              return res.status(500).json({ message: 'خطا در دریافت اطلاعات مشتریان' });
            }

            // Get top customers by purchase frequency
            const topCustomersByFrequencyQuery = `
              SELECT 
                customer_name,
                customer_phone,
                COUNT(*) as order_count,
                SUM(total_price) as total_purchase_amount
              FROM orders
              WHERE created_at >= ? AND status != 'cancelled'
              GROUP BY customer_name, customer_phone
              ORDER BY order_count DESC
              LIMIT 5
            `;

            db.query(topCustomersByFrequencyQuery, [startDate], (err, topCustomersByFrequency) => {
              if (err) {
                console.error(err);
                return res.status(500).json({ message: 'خطا در دریافت اطلاعات مشتریان' });
              }

              res.json({
                summary: results[0],
                topProducts,
                recentMovements,
                topCustomersByAmount,
                topCustomersByFrequency
              });
            });
          });
        });
      });
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Get order status report
router.get('/order-status', async (req, res) => {
  try {
    const { startDate, endDate } = req.query;
    let query = `
      SELECT 
        status,
        COUNT(*) as count,
        SUM(total_price) as total_value
      FROM orders
      WHERE 1=1
    `;
    const params = [];

    if (startDate) {
      query += ` AND DATE(created_at) >= ?`;
      params.push(startDate);
    }

    if (endDate) {
      query += ` AND DATE(created_at) <= ?`;
      params.push(endDate);
    }

    query += ` GROUP BY status ORDER BY count DESC`;

    db.query(query, params, (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت گزارش وضعیت سفارشات' });
      }
      res.json(results);
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});


module.exports = router; 