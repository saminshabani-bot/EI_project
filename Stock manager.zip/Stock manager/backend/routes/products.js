const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { body, validationResult } = require('express-validator');

// Get all products with search and filter
router.get('/', async (req, res) => {
  try {
    const { search, minStock } = req.query;
    let query = `
      SELECT p.* 
      FROM products p  
      WHERE 1=1
    `;
    const params = [];

    if (search) {
      query += ` AND (p.name LIKE ? OR p.description LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`);
    }


    if (minStock) {
      query += ` AND p.stock <= p.min_stock`;
    }

    query += ` ORDER BY p.created_at DESC`;

    db.query(query, params, (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت اطلاعات کالاها' });
      }
      res.json(results);
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Get single product
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const query = `
      SELECT p.* 
      FROM products p 
      WHERE p.id = ?
    `;

    db.query(query, [id], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت اطلاعات کالا' });
      }
      if (results.length === 0) {
        return res.status(404).json({ message: 'کالا یافت نشد' });
      }
      res.json(results[0]);
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Create new product
router.post('/', [
  body('name').notEmpty().withMessage('نام کالا الزامی است'),
  body('price').isFloat({ min: 0 }).withMessage('قیمت باید عدد مثبت باشد'),
  body('stock').isInt({ min: 0 }).withMessage('موجودی باید عدد صحیح مثبت باشد'),
  body('min_stock').isInt({ min: 0 }).withMessage('حداقل موجودی باید عدد صحیح مثبت باشد')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { name, description, price, stock, min_stock } = req.body;
    const query = `
      INSERT INTO products (name, description, price, stock, min_stock, created_at) 
      VALUES (?, ?, ?, ?, ?, ?, NOW())
    `;

    db.query(query, [name, description, price, stock, min_stock, ], (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در افزودن کالا' });
      }

      // Log inventory transaction
      const logQuery = `
        INSERT INTO inventory_logs (product_id, type, quantity, description, created_at) 
        VALUES (?, 'IN', ?, 'افزودن کالای جدید', NOW())
      `;
      db.query(logQuery, [result.insertId, stock]);

      res.status(201).json({ 
        message: 'کالا با موفقیت افزوده شد',
        id: result.insertId 
      });
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Update product
router.put('/:id', [
  body('name').notEmpty().withMessage('نام کالا الزامی است'),
  body('price').isFloat({ min: 0 }).withMessage('قیمت باید عدد مثبت باشد'),
  body('min_stock').isInt({ min: 0 }).withMessage('حداقل موجودی باید عدد صحیح مثبت باشد')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { id } = req.params;
    const { name, description, price, min_stock } = req.body;
    const query = `
      UPDATE products 
      SET name = ?, description = ?, price = ?, min_stock = ?, updated_at = NOW() 
      WHERE id = ?
    `;

    db.query(query, [name, description, price, min_stock, id], (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در بروزرسانی کالا' });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'کالا یافت نشد' });
      }
      res.json({ message: 'کالا با موفقیت بروزرسانی شد' });
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Delete product
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const query = 'DELETE FROM products WHERE id = ?';

    db.query(query, [id], (err, result) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در حذف کالا' });
      }
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: 'کالا یافت نشد' });
      }
      res.json({ message: 'کالا با موفقیت حذف شد' });
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Update stock
router.patch('/:id/stock', [
  body('quantity').isInt().withMessage('تعداد باید عدد صحیح باشد'),
  body('type').isIn(['IN', 'OUT']).withMessage('نوع تراکنش باید IN یا OUT باشد')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { id } = req.params;
    const { quantity, type, description } = req.body;

    // Get current stock
    db.query('SELECT stock FROM products WHERE id = ?', [id], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت موجودی' });
      }
      if (results.length === 0) {
        return res.status(404).json({ message: 'کالا یافت نشد' });
      }

      const currentStock = results[0].stock;
      let newStock;

      if (type === 'IN') {
        newStock = currentStock + quantity;
      } else {
        if (currentStock < quantity) {
          return res.status(400).json({ message: 'موجودی کافی نیست' });
        }
        newStock = currentStock - quantity;
      }

      // Update stock
      db.query('UPDATE products SET stock = ?, updated_at = NOW() WHERE id = ?', 
        [newStock, id], (err, result) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ message: 'خطا در بروزرسانی موجودی' });
        }

        // Log inventory transaction
        const logQuery = `
          INSERT INTO inventory_logs (product_id, type, quantity, description, created_at) 
          VALUES (?, ?, ?, ?, NOW())
        `;
        db.query(logQuery, [id, type, quantity, description || `${type === 'IN' ? 'افزودن' : 'کاهش'} موجودی`]);

        res.json({ 
          message: 'موجودی با موفقیت بروزرسانی شد',
          newStock 
        });
      });
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

module.exports = router; 