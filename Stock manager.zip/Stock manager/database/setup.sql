-- ایجاد دیتابیس
CREATE DATABASE IF NOT EXISTS inventory_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- انتخاب دیتابیس
USE inventory_db;

-- نمایش وضعیت دیتابیس
SELECT 'Database inventory_db created successfully!' as message; 