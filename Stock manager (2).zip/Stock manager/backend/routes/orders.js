const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { body, validationResult } = require('express-validator');

// Get all orders with search and filter
router.get('/', async (req, res) => {
  try {
    const { search, status, startDate, endDate } = req.query;
    let query = `
      SELECT o.*, p.name as product_name, p.price as product_price
      FROM orders o
      LEFT JOIN products p ON o.product_id = p.id
      WHERE 1=1
    `;
    const params = [];

    if (search) {
      query += ` AND (o.customer_name LIKE ? OR o.customer_phone LIKE ? OR p.name LIKE ?)`;
      params.push(`%${search}%`, `%${search}%`, `%${search}%`);
    }

    if (status) {
      query += ` AND o.status = ?`;
      params.push(status);
    }

    if (startDate) {
      query += ` AND DATE(o.created_at) >= ?`;
      params.push(startDate);
    }

    if (endDate) {
      query += ` AND DATE(o.created_at) <= ?`;
      params.push(endDate);
    }

    query += ` ORDER BY o.created_at DESC`;

    db.query(query, params, (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت اطلاعات سفارشات' });
      }
      res.json(results);
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Get single order
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const query = `
      SELECT o.*, p.name as product_name, p.price as product_price
      FROM orders o
      LEFT JOIN products p ON o.product_id = p.id
      WHERE o.id = ?
    `;

    db.query(query, [id], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت اطلاعات سفارش' });
      }
      if (results.length === 0) {
        return res.status(404).json({ message: 'سفارش یافت نشد' });
      }
      res.json(results[0]);
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Create new order
router.post('/', [
  body('product_id').isInt().withMessage('شناسه کالا الزامی است'),
  body('quantity').isInt({ min: 1 }).withMessage('تعداد باید حداقل 1 باشد'),
  body('customer_name').notEmpty().withMessage('نام مشتری الزامی است'),
  body('customer_phone').notEmpty().withMessage('شماره تماس مشتری الزامی است')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { product_id, quantity, customer_name, customer_phone, notes } = req.body;

    // Check product availability
    db.query('SELECT stock, price, name FROM products WHERE id = ?', [product_id], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در بررسی موجودی کالا' });
      }
      if (results.length === 0) {
        return res.status(404).json({ message: 'کالا یافت نشد' });
      }

      const product = results[0];
      if (product.stock < quantity) {
        return res.status(400).json({ message: 'موجودی کافی نیست' });
      }

      const total_price = product.price * quantity;

      // Create order
      const orderQuery = `
        INSERT INTO orders (product_id, quantity, total_price, customer_name, customer_phone, notes, status, created_at) 
        VALUES (?, ?, ?, ?, ?, ?, 'pending', NOW())
      `;

      db.query(orderQuery, [product_id, quantity, total_price, customer_name, customer_phone, notes], (err, result) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ message: 'خطا در ثبت سفارش' });
        }

        // Update product stock
        const newStock = product.stock - quantity;
        db.query('UPDATE products SET stock = ?, updated_at = NOW() WHERE id = ?', [newStock, product_id], (err) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ message: 'خطا در بروزرسانی موجودی' });
          }

          // Log inventory transaction
          const logQuery = `
            INSERT INTO inventory_logs (product_id, type, quantity, description, created_at) 
            VALUES (?, 'OUT', ?, 'سفارش مشتری: ${customer_name}', NOW())
          `;
          db.query(logQuery, [product_id, quantity]);

          res.status(201).json({ 
            message: 'سفارش با موفقیت ثبت شد',
            order_id: result.insertId,
            total_price
          });
        });
      });
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Update order status
router.patch('/:id/status', [
  body('status').isIn(['pending', 'shipped', 'cancelled']).withMessage('وضعیت نامعتبر است')
], async (req, res) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { id } = req.params;
    const { status } = req.body;

    // Get order details
    db.query('SELECT product_id, quantity, status as current_status FROM orders WHERE id = ?', [id], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت اطلاعات سفارش' });
      }
      if (results.length === 0) {
        return res.status(404).json({ message: 'سفارش یافت نشد' });
      }

      const order = results[0];

      // Handle stock changes based on status transitions
      if (status === 'cancelled' && order.current_status !== 'cancelled') {
        // Cancelling an order: restore stock
        db.query('UPDATE products SET stock = stock + ?, updated_at = NOW() WHERE id = ?', 
          [order.quantity, order.product_id], (err) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ message: 'خطا در بازگرداندن موجودی' });
          }

          // Log inventory transaction for cancellation
          const logQuery = `
            INSERT INTO inventory_logs (product_id, type, quantity, description, created_at) 
            VALUES (?, 'IN', ?, 'لغو سفارش', NOW())
          `;
          db.query(logQuery, [order.product_id, order.quantity], (logErr) => {
            if (logErr) {
              console.error('خطا در ثبت لاگ لغو سفارش:', logErr);
            }
          });
        });
      } else if ((status === 'shipped' || status === 'pending') && order.current_status === 'cancelled') {
        // Reactivating a cancelled order: reduce stock again
        db.query('UPDATE products SET stock = stock - ?, updated_at = NOW() WHERE id = ?', 
          [order.quantity, order.product_id], (err) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ message: 'خطا در کاهش موجودی' });
          }

          // Log inventory transaction for reactivation
          const logQuery = `
            INSERT INTO inventory_logs (product_id, type, quantity, description, created_at) 
            VALUES (?, 'OUT', ?, 'فعال‌سازی مجدد سفارش', NOW())
          `;
          db.query(logQuery, [order.product_id, order.quantity], (logErr) => {
            if (logErr) {
              console.error('خطا در ثبت لاگ فعال‌سازی مجدد:', logErr);
            }
          });
        });
      }

      // Update order status
      db.query('UPDATE orders SET status = ?, updated_at = NOW() WHERE id = ?', [status, id], (err, result) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ message: 'خطا در بروزرسانی وضعیت سفارش' });
        }
        res.json({ message: 'وضعیت سفارش با موفقیت بروزرسانی شد' });
      });
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

// Delete order
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;

    // Get order details before deletion
    db.query('SELECT product_id, quantity, status FROM orders WHERE id = ?', [id], (err, results) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: 'خطا در دریافت اطلاعات سفارش' });
      }
      if (results.length === 0) {
        return res.status(404).json({ message: 'سفارش یافت نشد' });
      }

      const order = results[0];

      // Restore stock if order is not cancelled
      if (order.status !== 'cancelled') {
        db.query('UPDATE products SET stock = stock + ?, updated_at = NOW() WHERE id = ?', 
          [order.quantity, order.product_id], (err) => {
          if (err) {
            console.error(err);
            return res.status(500).json({ message: 'خطا در بازگرداندن موجودی' });
          }

          // Log inventory transaction
          const logQuery = `
            INSERT INTO inventory_logs (product_id, type, quantity, description, created_at) 
            VALUES (?, 'IN', ?, 'حذف سفارش', NOW())
          `;
          db.query(logQuery, [order.product_id, order.quantity]);
        });
      }

      // Delete order
      db.query('DELETE FROM orders WHERE id = ?', [id], (err, result) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ message: 'خطا در حذف سفارش' });
        }
        res.json({ message: 'سفارش با موفقیت حذف شد' });
      });
    });
  } catch (error) {
    res.status(500).json({ message: 'خطا در سرور' });
  }
});

module.exports = router; 