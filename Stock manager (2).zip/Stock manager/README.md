### پیش‌نیازها
- Node.js
- MySQL
- npm 

###  نصب وابستگی‌ها
```bash
# یا به صورت دستی:
npm install
cd backend && npm install
cd ../frontend && npm install
```

###  راه‌اندازی دیتابیس
1. MySQL را اجرا کنید
2. فایل `database/schema.sql` را در MySQL اجرا کنید:
```bash
mysql -u root -p < database/schema.sql
```

###  تنظیم متغیرهای محیطی
فایل `backend/config.env` را ویرایش کنید:
```env
PORT=5000
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=inventory_db
JWT_SECRET=your_jwt_secret_key_here
NODE_ENV=development
```

###  اجرای برنامه
npm run server  # Backend در پورت 5000
npm run client  # Frontend در پورت 3000
```


