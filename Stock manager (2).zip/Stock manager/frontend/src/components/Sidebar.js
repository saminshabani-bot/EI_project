import React from 'react';
import { Nav } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import { 
  FaHome, 
  FaBoxes, 
  FaShoppingCart, 
  FaTags, 
  FaWarehouse, 
  FaChartBar,
  FaBars,
  FaTimes
} from 'react-icons/fa';

const Sidebar = ({ collapsed, onToggle, currentPath }) => {
  const menuItems = [
    { path: '/products', icon: <FaBoxes />, label: 'محصولات' },
    { path: '/orders', icon: <FaShoppingCart />, label: 'سفارشات' },
    { path: '/inventory', icon: <FaWarehouse />, label: 'موجودی' },
    { path: '/reports', icon: <FaChartBar />, label: 'گزارشات' },
  ];

  return (
    <div className={`sidebar ${collapsed ? 'collapsed' : ''}`}>
      <div className="d-flex justify-content-between align-items-center p-3 border-bottom border-light">
        <h5 className="mb-0 text-white">
          {!collapsed && 'سیستم انبار'}
        </h5>
        <button 
          className="btn btn-link text-white p-0"
          onClick={onToggle}
        >
          {collapsed ? <FaBars /> : <FaTimes />}
        </button>
      </div>
      
      <Nav className="flex-column p-3">
        {menuItems.map((item) => (
          <Nav.Link
            key={item.path}
            as={Link}
            to={item.path}
            className={`mb-2 ${currentPath === item.path ? 'active' : ''}`}
          >
            <span className="icon">{item.icon}</span>
            {!collapsed && <span className="label">{item.label}</span>}
          </Nav.Link>
        ))}
      </Nav>
      
      <div className="mt-auto p-3">
        <div className="text-center text-white-50">
          <small>نسخه 1.0.0</small>
        </div>
      </div>
    </div>
  );
};

export default Sidebar; 