import React, { useState, useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { Container, Row, Col } from 'react-bootstrap';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import Sidebar from './components/Sidebar';
import Products from './pages/Products';
import Orders from './pages/Orders';
import Inventory from './pages/Inventory';
import Reports from './pages/Reports';
import { Notify } from 'notiflix';

// تنظیمات Notiflix
Notify.init({
  position: 'top-right',
  timeout: 3000,
  clickToClose: true,
  pauseOnHover: true,
  rtl: true,
});

function App() {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const location = useLocation();

  // بررسی اتصال به سرور
  useEffect(() => {
    const checkServerConnection = async () => {
      try {
        const response = await fetch('/api/products');
        if (!response.ok) {
          Notify.failure('خطا در اتصال به سرور');
        }
      } catch (error) {
        Notify.failure('سرور در دسترس نیست');
      }
    };

    checkServerConnection();
  }, []);

  const toggleSidebar = () => {
    setSidebarCollapsed(!sidebarCollapsed);
  };

  return (
    <div className="App">
      <Container fluid>
        <Row>
          <Col md={sidebarCollapsed ? 2 : 3} className="p-0">
            <Sidebar 
              collapsed={sidebarCollapsed} 
              onToggle={toggleSidebar}
              currentPath={location.pathname}
            />
          </Col>
          <Col md={sidebarCollapsed ? 10 : 9} className="p-0">
            <div className="main-content">
              <Routes>
                <Route path="/products" element={<Products />} />
                <Route path="/orders" element={<Orders />} />
                <Route path="/inventory" element={<Inventory />} />
                <Route path="/reports" element={<Reports />} />
              </Routes>
            </div>
          </Col>
        </Row>
      </Container>
      
      {/* Toast Container for notifications */}
      <ToastContainer
        position="top-right"
        autoClose={5000}
        hideProgressBar={false}
        newestOnTop={false}
        closeOnClick
        rtl={true}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
      />
    </div>
  );
}

export default App; 