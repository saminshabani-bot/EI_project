import React, { useState, useEffect } from 'react';
import { 
  Card, 
  Table, 
  Button, 
  Modal, 
  Form, 
  Row, 
  Col, 
  InputGroup,
  Badge,
  Alert,
  Nav,
  Tab
} from 'react-bootstrap';
import { FaSearch, FaPlus, FaHistory, FaExclamationTriangle } from 'react-icons/fa';
import { Notify } from 'notiflix';
import moment from 'moment-jalaali';

const Inventory = () => {
  const [activeTab, setActiveTab] = useState('summary');
  const [inventoryHistory, setInventoryHistory] = useState([]);
  const [lowStockProducts, setLowStockProducts] = useState([]);
  const [summary, setSummary] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdjustModal, setShowAdjustModal] = useState(false);

  const [adjustForm, setAdjustForm] = useState({
    product_id: '',
    quantity: '',
    type: 'IN',
    description: ''
  });

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const fetchData = async () => {
    setLoading(true);
    try {
      switch (activeTab) {
        case 'summary':
          await fetchSummary();
          break;
        case 'history':
          await fetchInventoryHistory();
          break;
        case 'low-stock':
          await fetchLowStockProducts();
          break;
      }
    } catch (error) {
      Notify.failure('خطا در دریافت اطلاعات');
    } finally {
      setLoading(false);
    }
  };

  const fetchSummary = async () => {
    try {
      const response = await fetch('/api/inventory/summary');
      if (response.ok) {
        const data = await response.json();
        setSummary(data);
      }
    } catch (error) {
      console.error('خطا در دریافت خلاصه:', error);
    }
  };

  const fetchInventoryHistory = async () => {
    try {
      const response = await fetch('/api/inventory/history');
      if (response.ok) {
        const data = await response.json();
        setInventoryHistory(data);
      }
    } catch (error) {
      console.error('خطا در دریافت تاریخچه:', error);
    }
  };

  const fetchLowStockProducts = async () => {
    try {
      const response = await fetch('/api/inventory/low-stock');
      if (response.ok) {
        const data = await response.json();
        setLowStockProducts(data);
      }
    } catch (error) {
      console.error('خطا در دریافت کالاهای کم‌موجود:', error);
    }
  };

  const fetchProducts = async () => {
    try {
      const response = await fetch('/api/products');
      if (response.ok) {
        const data = await response.json();
        setProducts(data);
      }
    } catch (error) {
      console.error('خطا در دریافت محصولات:', error);
    }
  };

  const handleAdjustSubmit = async (e) => {
    e.preventDefault();
    
    try {
      const response = await fetch('/api/inventory/adjust', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(adjustForm),
      });

      if (response.ok) {
        const result = await response.json();
        Notify.success('موجودی با موفقیت تنظیم شد');
        setShowAdjustModal(false);
        resetAdjustForm();
        fetchData();
      } else {
        const error = await response.json();
        Notify.failure(error.message || 'خطا در تنظیم موجودی');
      }
    } catch (error) {
      Notify.failure('خطا در اتصال به سرور');
    }
  };

  const resetAdjustForm = () => {
    setAdjustForm({
      product_id: '',
      quantity: '',
      type: 'IN',
      description: ''
    });
  };

  const formatNumber = (num) => {
    return new Intl.NumberFormat('fa-IR').format(num);
  };

  const formatCurrency = (num) => {
    return new Intl.NumberFormat('fa-IR').format(num) + ' تومان';
  };

  const getTypeBadge = (type) => {
    return type === 'IN' 
      ? <Badge bg="success">ورود</Badge>
      : <Badge bg="danger">خروج</Badge>;
  };

  if (loading) {
    return (
      <div className="text-center p-5">
        <div className="spinner-border text-primary" role="status">
          <span className="visually-hidden">در حال بارگذاری...</span>
        </div>
      </div>
    );
  }

  return (
    <div className="fade-in">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>مدیریت موجودی</h2>
        <Button 
          variant="primary" 
          onClick={() => {
            fetchProducts();
            setShowAdjustModal(true);
          }}
        >
          <FaPlus className="me-2" />
          تنظیم موجودی
        </Button>
      </div>

      {/* تب‌ها */}
      <Card>
        <Card.Header>
          <Nav variant="tabs" activeKey={activeTab} onSelect={setActiveTab}>
            <Nav.Item>
              <Nav.Link eventKey="summary">خلاصه موجودی</Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="history">تاریخچه موجودی</Nav.Link>
            </Nav.Item>
            <Nav.Item>
              <Nav.Link eventKey="low-stock">
                <FaExclamationTriangle className="me-1" />
                کم‌موجود
              </Nav.Link>
            </Nav.Item>
          </Nav>
        </Card.Header>
        <Card.Body>
          <Tab.Content>
            <Tab.Pane active={activeTab === 'summary'}>
              {summary && (
                <Row>
                  <Col md={3} className="mb-3">
                    <Card className="dashboard-card text-center">
                      <div className="number">{formatNumber(summary.total_products)}</div>
                      <div className="label">کل محصولات</div>
                    </Card>
                  </Col>
                  <Col md={3} className="mb-3">
                    <Card className="dashboard-card text-center">
                      <div className="number">{formatNumber(summary.total_stock)}</div>
                      <div className="label">کل موجودی</div>
                    </Card>
                  </Col>
                  <Col md={3} className="mb-3">
                    <Card className="dashboard-card text-center">
                      <div className="number text-warning">{formatNumber(summary.low_stock_count)}</div>
                      <div className="label">کم‌موجود</div>
                    </Card>
                  </Col>
                </Row>
              )}
            </Tab.Pane>

            <Tab.Pane active={activeTab === 'history'}>
              <Table responsive hover>
                <thead>
                  <tr>
                    <th>محصول</th>
                    <th>نوع</th>
                    <th>تعداد</th>
                    <th>توضیحات</th>
                    <th>تاریخ</th>
                  </tr>
                </thead>
                <tbody>
                  {inventoryHistory.map(item => (
                    <tr key={item.id}>
                      <td>{item.product_name}</td>
                      <td>{getTypeBadge(item.type)}</td>
                      <td>{formatNumber(item.quantity)}</td>
                      <td>{item.description}</td>
                      <td>{moment(item.created_at).format('jYYYY/jMM/jDD HH:mm')}</td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Tab.Pane>

            <Tab.Pane active={activeTab === 'low-stock'}>
              <Table responsive hover>
                <thead>
                  <tr>
                    <th>محصول</th>
                    <th>موجودی فعلی</th>
                    <th>حداقل موجودی</th>
                    <th>وضعیت</th>
                  </tr>
                </thead>
                <tbody>
                  {lowStockProducts.map(product => (
                    <tr key={product.id}>
                      <td>
                        <strong>{product.name}</strong>
                        <small className="text-muted d-block">
                          {formatCurrency(product.price)} هر واحد
                        </small>
                      </td>
                      <td>
                        <span className="stock-low">
                          {formatNumber(product.stock)}
                        </span>
                      </td>
                      <td>{formatNumber(product.min_stock)}</td>
                      <td>
                        <Badge bg={product.stock === 0 ? 'danger' : 'warning'}>
                          {product.stock === 0 ? 'ناموجود' : 'کم‌موجود'}
                        </Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </Table>
            </Tab.Pane>
          </Tab.Content>
        </Card.Body>
      </Card>

      {/* مودال تنظیم موجودی */}
      <Modal show={showAdjustModal} onHide={() => setShowAdjustModal(false)}>
        <Modal.Header closeButton>
          <Modal.Title>تنظیم موجودی</Modal.Title>
        </Modal.Header>
        <Form onSubmit={handleAdjustSubmit}>
          <Modal.Body>
            <Form.Group className="mb-3">
              <Form.Label>محصول *</Form.Label>
              <Form.Select
                value={adjustForm.product_id}
                onChange={(e) => setAdjustForm({...adjustForm, product_id: e.target.value})}
                required
              >
                <option value="">انتخاب محصول</option>
                {products.map(product => (
                  <option key={product.id} value={product.id}>
                    {product.name} - موجودی فعلی: {product.stock}
                  </option>
                ))}
              </Form.Select>
            </Form.Group>
            <Row>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>نوع تراکنش *</Form.Label>
                  <Form.Select
                    value={adjustForm.type}
                    onChange={(e) => setAdjustForm({...adjustForm, type: e.target.value})}
                    required
                  >
                    <option value="IN">ورود</option>
                    <option value="OUT">خروج</option>
                  </Form.Select>
                </Form.Group>
              </Col>
              <Col md={6}>
                <Form.Group className="mb-3">
                  <Form.Label>تعداد *</Form.Label>
                  <Form.Control
                    type="number"
                    value={adjustForm.quantity}
                    onChange={(e) => setAdjustForm({...adjustForm, quantity: e.target.value})}
                    required
                    min="1"
                  />
                </Form.Group>
              </Col>
            </Row>
            <Form.Group className="mb-3">
              <Form.Label>توضیحات</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                value={adjustForm.description}
                onChange={(e) => setAdjustForm({...adjustForm, description: e.target.value})}
                placeholder="دلیل تنظیم موجودی..."
              />
            </Form.Group>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={() => setShowAdjustModal(false)}>
              لغو
            </Button>
            <Button variant="primary" type="submit">
              تنظیم موجودی
            </Button>
          </Modal.Footer>
        </Form>
      </Modal>
    </div>
  );
};

export default Inventory; 